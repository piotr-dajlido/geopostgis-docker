create function st_crosses(geom1 geometry, geom2 geometry)
  returns boolean
immutable
parallel safe
language sql
as $$
SELECT $1 OPERATOR(public.&&) $2 AND public._ST_Crosses($1,$2)
$$;

comment on function st_crosses(geometry, geometry)
is 'args: g1, g2 - Returns TRUE if the supplied geometries have some, but not all, interior points in common.';

alter function st_crosses(geometry, geometry)
  owner to postgres;

