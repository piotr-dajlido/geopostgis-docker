create function st_locate_along_measure(geometry, double precision)
  returns geometry
immutable
strict
parallel safe
language sql
as $$
SELECT public.ST_locate_between_measures($1, $2, $2)
$$;

alter function st_locate_along_measure(geometry, double precision)
  owner to postgres;

