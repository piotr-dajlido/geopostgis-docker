create function st_asgeojson(geog geography, maxdecimaldigits integer DEFAULT 15, options integer DEFAULT 0)
  returns text
immutable
strict
parallel safe
language sql
as $$
SELECT public._ST_AsGeoJson(1, $1, $2, $3);
$$;

comment on function st_asgeojson(geography, integer, integer)
is 'args: geog, maxdecimaldigits=15, options=0 - Return the geometry as a GeoJSON element.';

alter function st_asgeojson(geography, integer, integer)
  owner to postgres;

