create function st_pixelascentroid(rast raster, x integer, y integer)
  returns geometry
immutable
strict
parallel safe
language sql
as $$
SELECT public.ST_Centroid(geom) FROM public._ST_pixelaspolygons($1, NULL, $2, $3)
$$;

comment on function st_pixelascentroid(raster, integer, integer)
is 'args: rast, x, y - Returns the centroid (point geometry) of the area represented by a pixel.';

alter function st_pixelascentroid(raster, integer, integer)
  owner to postgres;

