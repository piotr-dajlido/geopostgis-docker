create function st_mapalgebra(rast raster, pixeltype text, expression text, nodataval double precision DEFAULT NULL::double precision)
  returns raster
immutable
parallel safe
language sql
as $$
SELECT public.ST_mapalgebra($1, 1, $2, $3, $4)
$$;

alter function st_mapalgebra(raster, text, text, double precision)
  owner to postgres;

