create function st_quantile(rastertable text, rastercolumn text, quantiles double precision[], OUT quantile double precision, OUT value double precision)
  returns SETOF record
stable
strict
language sql
as $$
SELECT public._ST_quantile($1, $2, 1, TRUE, 1, $3)
$$;

alter function st_quantile(text, text, double precision [], out double precision, out double precision)
  owner to postgres;

