create function st_bandmetadata(rast raster, band integer DEFAULT 1, OUT pixeltype text, OUT nodatavalue double precision, OUT isoutdb boolean, OUT path text, OUT outdbbandnum integer, OUT filesize bigint, OUT filetimestamp bigint)
  returns record
immutable
strict
parallel safe
language sql
as $$
SELECT pixeltype, nodatavalue, isoutdb, path, outdbbandnum, filesize, filetimestamp FROM public.ST_BandMetaData($1, ARRAY[$2]::int[]) LIMIT 1
$$;

comment on function st_bandmetadata(raster, integer, out text, out double precision, out boolean,
                                                     out text, out integer, out bigint, out bigint)
is 'args: rast, band=1 - Returns basic meta data for a specific raster band. band num 1 is assumed if none-specified.';

alter function st_bandmetadata(raster, integer, out text, out double precision, out boolean, out text, out integer, out bigint, out bigint)
  owner to postgres;

